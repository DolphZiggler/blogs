#pragma once

struct Thing
{
};

void do_a_thing( Thing thing );
void do_another_thing();
